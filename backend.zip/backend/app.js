import fs from 'node:fs/promises';

import bodyParser from 'body-parser';
import express from 'express';

const app = express();

app.use(express.static('images'));
app.use(bodyParser.json());

// CORS

app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, PUT');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  next();
});

app.get('/places', async (req, res) => {
  const fileContent = await fs.readFile('./data/places.json');

  const placesData = JSON.parse(fileContent);

  res.status(200).json({ places: placesData });
});

app.get('/user-places', async (req, res) => {
  const fileContent = await fs.readFile('./data/user-places.json');

  const places = JSON.parse(fileContent);

  res.status(200).json({ places });
});

app.put('/user-places', async (req, res) => {
  const places = req.body.places;

  await fs.writeFile('./data/user-places.json', JSON.stringify(places));

  res.status(200).json({ message: 'User places updated!' });
});

// 404
app.use((req, res, next) => {
  if (req.method === 'OPTIONS') {
    return next();
  }
  res.status(404).json({ message: '404 - Not Found' });
});

app.listen(3000);















/////////////////////////////////////////////////////
// import express from "express";
// import fs from "fs";

// const app = express();
// const port = 3000;

// // Middleware to parse JSON bodies
// app.use(express.json());


// app.use((req, res, next) => {
//   res.setHeader('Access-Control-Allow-Origin', '*'); // allow all domains

//   next();
// });

// app.get('/', (req, res) => {
//   res.send('Welcome to my server!');
// });

// app.get('/test', (req, res) => {
//   res.send('Welcome to my server and test!');
// });

// app.post('/data', (req, res) => {
//   const Data = req.body;

//   // Read existing data from the data.json file, if any
//   let existingData = [];
//   try {
//     const dataJson = fs.readFileSync('data.json');
//     existingData = JSON.parse(dataJson);
//   } catch (error) {
//     console.error('Error reading data.json:', error);
//   }

//   // Add new data to the existing data array
//   existingData.push(Data);

//   // Write updated data back to the data.json file
//   fs.writeFile('data.json', JSON.stringify(existingData, null, 2), (err) => {
//     if (err) {
//       console.error('Error writing to data.json:', err);
//       res.status(500).send('Error saving data');
//       return;
//     }
//     console.log('Data saved to data.json:', Data);
//     res.send('Data saved successfully');
//   });
// });

// app.listen(port, () => {
//   console.log(`Server is running on port ${port}`);
// });

////////////////////////////////////////////////////////////////////////////////////////////////////////////
// import express from "express";

// const app = express();
// const port = 3000;

// app.get('/', (req, res) => {
//   res.send('Welcome to my server!');
// });
// app.get('/test', (req, res) => {
//   res.send('Welcome to my server and test!');
// });
// app.post('/data', (req, res) => {
//   res.send('Welcome to my server!');
// });

// app.listen(port, () => {
//   console.log(`Server is running on port ${port}`);
// });