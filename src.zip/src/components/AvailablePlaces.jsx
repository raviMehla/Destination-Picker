import { useState, useEffect } from "react";
import Places from "./Places.jsx";

export default function AvailablePlaces({ onSelectPlace }) {
  const [availablePlaces, setAvailalblePlaces] = useState([]);

  useEffect(() => {
    async function getPlace() {
      const response = await fetch("http://localhost:3000/places");
      const resData = await response.json();
      setAvailalblePlaces(resData.places);
      console.log("Places are : ", resData.places);
    }

    getPlace();
    // fetch("http://localhost:3000/places")
    //   .then((response) => {
    //     return response.json();
    //   })
    //   .then((resData) => {
    //     setAvailalblePlaces(resData.places);
    //   })
    //   .catch(function (err) {
    //     console.log("Unable to fetch -", err);
    //   });
  }, []);

  return (
    <Places
      title="Available Places"
      places={availablePlaces}
      fallbackText="No places available."
      onSelectPlace={onSelectPlace}
    />
  );
}
